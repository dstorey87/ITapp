# EVE Online Capital Ship Production Management

## Setup Instructions
1. Ensure Docker Desktop is installed and running.
2. Navigate to `E:\DockerProject`.
3. Run `docker-compose up -d` to start the containers.

## Accessing the Application
Visit `http://localhost:8080` in your browser.
