<?php
// worker_corp_details.php

include 'includes/db.php';  // Path updated to the includes directory
include 'includes/oauth.php';  // Path updated to the includes directory

$corporationID = 146531499;  // Corporation ID

// Start API request
log_message("Worker script started");
log_message("Starting API request for corporation ID: $corporationID");

// Make API request
$url = "https://esi.evetech.net/latest/corporations/$corporationID/";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);

if (curl_errno($ch)) {
    log_message("Curl error: " . curl_error($ch));
    die("Curl error: " . curl_error($ch));
} else {
    log_message("API request successful. Response: " . $response);
}
curl_close($ch);

// Decode the JSON response
$corpData = json_decode($response, true);

if (isset($corpData['corporation_id'])) {
    // Prepare the data
    $name = $corpData['name'] ?? 'Unknown';
    $ticker = $corpData['ticker'] ?? 'Unknown';
    $date_founded = substr($corpData['date_founded'], 0, 10);  // Extract only the date

    // Cache the data in the database
    $query = "REPLACE INTO corp_cache (corporation_id, name, ticker, date_founded, timestamp)
              VALUES ('$corporationID', '$name', '$ticker', '$date_founded', NOW())";
    log_message("SQL Query: $query");

    if (mysqli_query($conn, $query)) {
        log_message("Corporation details successfully cached in the database.");
        echo "Corporation details successfully cached in the database.\n";
    } else {
        log_message("Database error: " . mysqli_error($conn));
        die("Database error: " . mysqli_error($conn));
    }
} else {
    log_message("Error: Corporation data is missing or invalid.");
    echo "Error: Corporation data is missing or invalid.\n";
}
?>
