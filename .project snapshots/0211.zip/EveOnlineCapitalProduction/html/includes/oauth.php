<?php
// oauth.php
session_start();

// OAuth configuration
$clientID = '523dcd00cdfe40e8b11a455adf02fc65';
$clientSecret = 'ZbQiT940vfmxTun4riqZjGNw2imohWgiehn5cEaB';
$redirectUri = 'http://localhost:8080/includes/callback.php';
$scope = 'publicData';

// Generate a random state to prevent CSRF attacks
$state = bin2hex(random_bytes(16));
$_SESSION['oauth2_state'] = $state;

// If an authorization code is present, exchange it for an access token
if (isset($_GET['code'])) {
    if (isset($_GET['state']) && $_GET['state'] === $_SESSION['oauth2_state']) {
        // Exchange authorization code for an access token
        $code = $_GET['code'];
        $tokenUrl = 'https://login.eveonline.com/v2/oauth/token';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $tokenUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Basic ' . base64_encode("$clientID:$clientSecret")
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $redirectUri,
        ]));

        $response = curl_exec($ch);
        if ($error = curl_error($ch)) {
            die("Error retrieving access token: $error");
        }
        curl_close($ch);

        $responseData = json_decode($response, true);
        if (isset($responseData['access_token'])) {
            $_SESSION['access_token'] = $responseData['access_token'];
            header('Location: /src/index.php');  // Redirect to index.php after successful auth
            exit();
        } else {
            die("Error retrieving access token: " . print_r($responseData, true));
        }
    } else {
        die("Invalid state parameter.");
    }
} else {
    // Redirect user to EVE Online authorization page
    $authUrl = "https://login.eveonline.com/v2/oauth/authorize?response_type=code&client_id=$clientID&redirect_uri=" . urlencode($redirectUri) . "&scope=$scope&state=" . urlencode($state);
    header("Location: $authUrl");
    exit();
}
?>
