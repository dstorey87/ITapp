<?php
// db.php

// MySQL database connection settings
$servername = "db";  // The Docker service name, previously was 'localhost'
$username = "eve_user";  // Your Docker project's DB user
$password = "your_password";  // Database password
$dbname = "eve_online";  // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Logging function to log errors or information
function log_message($message) {
    $log_file = '../logs/log.txt';  // Path updated to the new 'logs' directory
    file_put_contents($log_file, date('[Y-m-d H:i:s] ') . $message . PHP_EOL, FILE_APPEND);
}
?>
