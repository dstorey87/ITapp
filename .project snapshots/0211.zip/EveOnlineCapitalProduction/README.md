Project Documentation: Eve Online Capital Ship Production
