<?php
// worker_corp_details.php

include 'db.php';  // Ensure this points to the correct database connection
echo "Worker script started\n";

// Corporation ID
$corporationID = 146531499;  

// Bypass cache and forcefully pull new data from the ESI API
echo "Starting API request for corporation ID: " . $corporationID . "\n";
$url = "https://esi.evetech.net/latest/corporations/$corporationID/";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo "Curl error: " . curl_error($ch) . "\n";
    die("Curl error: " . curl_error($ch));
} else {
    echo "API request successful. Response: " . $response . "\n";
}
curl_close($ch);

// Decode the JSON response
$corpData = json_decode($response, true);
echo "Decoded JSON response: " . print_r($corpData, true) . "\n";

// Validate data by checking 'name' instead of 'corporation_id'
if (isset($corpData['name'])) {
    // Cache the data in the database
    $name = $corpData['name'] ?? 'Unknown';
    $ticker = $corpData['ticker'] ?? 'Unknown';
    $date_founded = isset($corpData['date_founded']) ? substr($corpData['date_founded'], 0, 10) : '0000-00-00';

    // Output SQL query for verification
    $query = "REPLACE INTO corp_cache (corporation_id, name, ticker, date_founded, timestamp) 
              VALUES ('$corporationID', '$name', '$ticker', '$date_founded', NOW())";
    echo "SQL Query: " . $query . "\n";

    if (mysqli_query($conn, $query)) {
        echo "Corporation details successfully cached in the database.\n";
    } else {
        echo "Database error: " . mysqli_error($conn) . "\n";
    }
} else {
    echo "Error: Corporation name is missing or invalid.\n";
}
