<?php
// db.php

// MySQL database connection settings
$servername = "db";  // Use the Docker service name for MariaDB
$username = "eve_user";
$password = "your_password";
$dbname = "eve_online";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Only define log_message if it doesn't already exist
if (!function_exists('log_message')) {
    function log_message($message) {
        $log_file = 'log.txt';
        file_put_contents($log_file, date('[Y-m-d H:i:s] ') . $message . PHP_EOL, FILE_APPEND);
    }
}
?>
